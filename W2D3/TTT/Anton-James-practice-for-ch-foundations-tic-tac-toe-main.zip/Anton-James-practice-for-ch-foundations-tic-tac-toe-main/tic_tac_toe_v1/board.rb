class Board

    def initialize
        @grid = Array.new(3) { Array.new(3) }
        @grid.each do |sub|
            sub.map! { |ele| ele = "_" }
        end
    end

    def valid?(position)
        return false if position[0] > 2 || position[0] < 0 || position[-1] > 2 || position[-1] < 0
        true
    end

    def empty?(position)
        return false if @grid[position[0]][position[-1]] != "_"
        true
    end

    def place_mark(position, mark)
        if !self.valid?(position) || !self.empty?(position)
            raise "Invalid mark"
        else
            @grid[position[0]][position[-1]] = mark
        end
    end

    def print
        @grid.each do |row|
            joined = row.join(" ")
            puts joined
        end
    end

    def win_row?(mark)
        row = 0
        while row < 3
            i = 0
            win_count = 0
            while i < 3
                win_count += 1 if @grid[row][i] == mark
                i+=1
            end
            return true if win_count == 3
            row+=1
        end
        false
    end

    def win_col?(mark)
        row = 0
        while row < 3
            i = 0
            win_count = 0
            while i < 3
                win_count += 1 if @grid[i][row] == mark
                i+=1
            end
            return true if win_count == 3
            row+=1
        end
        false
    end


end