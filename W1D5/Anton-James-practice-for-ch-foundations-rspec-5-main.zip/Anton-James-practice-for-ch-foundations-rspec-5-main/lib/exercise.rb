require "byebug"

def zip(*arr)
    arr.length
    
end

array_1 = ['a', 'b', 'c'] 
array_2 = [1, 2, 3]
array_3 = ['w', 'x', 'y']

print zip(array_1, array_2) 

def prizz_proc(arr, prc1, prc2)
    result = []

    arr.each { |ele| result << ele if (prc1[ele] == true || prc2[ele] == true) && !(prc1[ele] == true && prc2[ele] == true) }

    result
end

# def zany_zip(*matrix)
#     matrix.zip { ... }
# end

def maximum(arr, &prc)
    return nil if arr.length == 0

    scores = arr.map { |ele| prc[ele] }
    
    looking_idx = max_finder(scores)
    arr[looking_idx]
end

def max_finder(scores) # [4, 3, 4]
    winner = 0 
    idx = 0

    i = 0
    while i < scores.length
        if scores[i] >= winner
            winner = scores[i]
            idx = i
        end
        i+=1
    end

    idx
end

def my_group_by(arr, &prc)
    result = {}

    arr.each { |ele| result[prc[ele]] = [] }
    arr.each { |ele| result[prc[ele]] << ele }

    result
end

def max_tie_breaker(arr, prc, &blc)
    temp_winner = 0
    result = 0

    return nil if arr.length == 0

    arr.each do |ele|
        if temp_winner < blc[ele]
            temp_winner = blc[ele]
            result = ele
        end
    end
    result
end

def silly_syllables(sent)
    words = sent.split 
    new_sent = []

    words.each { |word| vowels_count(word) < 2 ? new_sent << word : new_sent << vowels_remover(word) }

    new_sent.join(" ")
end

def vowels_count(word)
    count = 0
    word.each_char { |char| count+= 1 if "aeiouAEIOU".include?(char) }
    count
end

def vowels_remover(word)
    temp_word = ""

    word.each_char.with_index do |char,idx|
        if "aeiouAEIOU".include?(char)
            temp_word = word[idx..-1]
            break
        end
    end

    i = temp_word.length-1
    while i >= 0
        if "aeiouAEIOU".include?(temp_word[i])
            return temp_word[0..i]
        end
        i-=1
    end

end

