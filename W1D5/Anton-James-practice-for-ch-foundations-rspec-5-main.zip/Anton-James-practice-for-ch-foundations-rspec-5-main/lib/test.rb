def max_tie_breaker(arr, prc, &blc)
    temp_winner = 0
    result = 0

    arr.each do |ele|
        if temp_winner < blc[ele]
            temp_winner = blc[ele]
            result = ele
        # elsif blc[ele] == temp_winner 
        #     if prc[ele] >= prc[temp_winner]
        #         temp_winner = blc[ele]
        #         result = ele
        #     else
        #         temp_winner = prc[temp_winner]
        #     end
        end
    end

    result
end

array_1 = ['potato', 'swimming', 'cat']
array_2 = ['cat', 'bootcamp', 'swimming', 'ooooo']
array_3 = ['photo','bottle', 'bother']
length = Proc.new { |s| s.length }
o_count = Proc.new { |s| s.count('o') }

print max_tie_breaker(array_1, length, &o_count)










# def zip(*arr)
#     length = arr.length

    
# end

# array_1 = ['a', 'b', 'c'] 
# array_2 = [1, 2]
# array_3 = ['w', 'x', 'y']

# p zip(array_1, array_3)